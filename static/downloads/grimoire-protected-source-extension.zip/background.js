const DEFAULT_GATEWAY_URL = 'http://127.0.0.1:8787';
let activePoll;

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function config() {
  const stored = await chrome.storage.local.get(['gatewayUrl', 'gatewayToken']);
  return {
    gatewayUrl: (stored.gatewayUrl || DEFAULT_GATEWAY_URL).replace(/\/$/, ''),
    gatewayToken: (stored.gatewayToken || '').trim()
  };
}

function authorization(token) {
  return { Authorization: `Bearer ${token}` };
}

async function completeJob(settings, job) {
  let result;
  try {
    const response = await fetch(job.url, {
      credentials: 'include',
      redirect: 'follow',
      cache: 'no-store',
      headers: { Accept: 'text/html,application/xhtml+xml,application/json,*/*', ...(job.headers || {}) }
    });
    result = {
      id: job.id,
      finalUrl: response.url,
      html: await response.text(),
      status: response.status
    };
  } catch (error) {
    result = {
      id: job.id,
      error: error instanceof Error ? error.message : 'Extension fetch failed',
      status: 502
    };
  }

  await fetch(`${settings.gatewayUrl}/v1/extension/result`, {
    method: 'POST',
    headers: {
      ...authorization(settings.gatewayToken),
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(result)
  });
}

async function pollForever() {
  while (true) {
    const settings = await config();
    if (!settings.gatewayToken) {
      await delay(3_000);
      continue;
    }

    try {
      activePoll = new AbortController();
      const response = await fetch(`${settings.gatewayUrl}/v1/extension/poll`, {
        headers: authorization(settings.gatewayToken),
        cache: 'no-store',
        signal: activePoll.signal
      });
      activePoll = undefined;
      if (response.status === 204) continue;
      if (!response.ok) throw new Error(`Gateway poll returned HTTP ${response.status}`);
      const payload = await response.json();
      if (payload.job) await completeJob(settings, payload.job);
    } catch (error) {
      activePoll = undefined;
      if (error instanceof Error && error.name === 'AbortError') continue;
      await delay(2_000);
    }
  }
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === 'configUpdated') {
    activePoll?.abort();
    sendResponse({ ok: true });
  }
});

pollForever();
